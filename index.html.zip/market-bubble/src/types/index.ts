export type Platform = 'twitch' | 'x' | 'kick' | 'bubble';

export interface ChatMessage {
  id: string;
  platform: Platform;
  username: string;
  avatar: string;
  content: string;
  timestamp: Date;
  followers?: number;
  bio?: string;
  verified?: boolean;
  translatedContent?: Record<string, string>;
}

export interface Stream {
  id: string;
  title: string;
  platform: Platform;
  host: string;
  viewers: number;
  thumbnail: string;
  category: string;
  live: boolean;
  duration: string;
  guests: string[];
}

export interface Guest {
  id: string;
  name: string;
  avatar: string;
  bio: string;
  company: string;
  role: string;
  expertise: string[];
  xHandle: string;
  website: string;
  followers: string;
  featured: boolean;
}

export interface MarketAsset {
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  changePct24h: number;
  volume: string;
  marketCap: string;
  sentiment: 'bullish' | 'bearish' | 'neutral';
  sparkline: number[];
}

export interface Narrative {
  id: string;
  topic: string;
  mentions: number;
  sentiment: 'bullish' | 'bearish' | 'neutral';
  trend: 'up' | 'down' | 'flat';
  change: number;
}

export interface AISegment {
  label: string;
  icon: string;
  content: string[];
}

export interface AISummary {
  generatedAt: Date;
  duration: string;
  totalMessages: number;
  segments: AISegment[];
}

export type Language = 'en' | 'fr' | 'es' | 'pt' | 'ar' | 'zh';

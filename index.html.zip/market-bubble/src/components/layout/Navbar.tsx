'use client';
import { motion } from 'framer-motion';
import { Bell, Settings, Search, Menu, X } from 'lucide-react';
import { useState } from 'react';

const NAV_ITEMS = ['Dashboard', 'AI Summary', 'Guests', 'Markets', 'Settings'];

interface NavbarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export default function Navbar({ activeTab, onTabChange }: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="h-14 border-b border-bubble-border glass-panel flex items-center px-4 gap-4 relative z-50">
      {/* Logo */}
      <div className="flex items-center gap-2.5 mr-4 flex-shrink-0">
        <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-bubble-accent to-bubble-accent2 flex items-center justify-center">
          <span className="text-xs font-black text-white">MB</span>
        </div>
        <div className="hidden sm:block">
          <span className="font-display font-bold text-sm text-bubble-text tracking-tight">Market</span>
          <span className="font-display font-bold text-sm accent-text tracking-tight"> Bubble</span>
        </div>
      </div>

      {/* Desktop nav */}
      <nav className="hidden md:flex items-center gap-1 flex-1">
        {NAV_ITEMS.map((item) => (
          <button
            key={item}
            onClick={() => onTabChange(item)}
            className={`relative px-3 py-1.5 text-xs font-medium rounded-lg transition-all duration-200 ${
              activeTab === item
                ? 'text-bubble-accent'
                : 'text-bubble-muted hover:text-bubble-text hover:bg-white/5'
            }`}
          >
            {activeTab === item && (
              <motion.div
                layoutId="nav-active"
                className="absolute inset-0 rounded-lg bg-bubble-accent/10 border border-bubble-accent/20"
                transition={{ type: 'spring', bounce: 0.2, duration: 0.4 }}
              />
            )}
            <span className="relative">{item}</span>
          </button>
        ))}
      </nav>

      {/* Right section */}
      <div className="flex items-center gap-2 ml-auto">
        {/* Simulcast status pill — shows Market Bubble is live on all 3 platforms */}
        <div className="hidden lg:flex items-center gap-2 glass-panel rounded-full px-3 py-1.5 border border-bubble-green/20 bg-bubble-green/5">
          <motion.span
            animate={{ opacity: [1, 0.4, 1] }}
            transition={{ duration: 1.6, repeat: Infinity }}
            className="w-1.5 h-1.5 rounded-full bg-bubble-green shadow-glow-green flex-shrink-0"
          />
          <span className="text-[10px] font-mono text-bubble-green font-semibold tracking-wider">LIVE</span>
          <span className="w-px h-3 bg-bubble-border" />
          <span className="text-[10px] font-mono text-bubble-muted">📡 Twitch</span>
          <span className="text-[10px] font-mono text-bubble-muted">⚡ Kick</span>
          <span className="text-[10px] font-mono text-bubble-muted">𝕏 X</span>
        </div>

        {/* Market ticker pill */}
        <div className="hidden xl:flex items-center gap-3 glass-panel rounded-full px-3 py-1 text-xs font-mono">
          <span className="text-bubble-muted">BTC</span>
          <span className="text-bubble-green font-semibold">$104,280</span>
          <span className="text-bubble-green">+2.30%</span>
          <span className="w-px h-3 bg-bubble-border" />
          <span className="text-bubble-muted">SOL</span>
          <span className="text-bubble-green font-semibold">$187.42</span>
          <span className="text-bubble-green">+7.35%</span>
        </div>

        <button className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/5 text-bubble-muted hover:text-bubble-text transition-colors">
          <Search size={15} />
        </button>
        <button className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/5 text-bubble-muted hover:text-bubble-text transition-colors relative">
          <Bell size={15} />
          <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-bubble-accent" />
        </button>
        <div className="w-7 h-7 rounded-full bg-gradient-to-br from-bubble-accent/40 to-bubble-accent2/40 flex items-center justify-center text-xs font-bold text-bubble-accent border border-bubble-accent/20">
          ZB
        </div>
        <button
          className="md:hidden w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/5 text-bubble-muted"
          onClick={() => setMobileOpen(!mobileOpen)}
        >
          {mobileOpen ? <X size={15} /> : <Menu size={15} />}
        </button>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute top-14 left-0 right-0 glass-panel border-b border-bubble-border p-3 flex flex-col gap-1 md:hidden"
        >
          {NAV_ITEMS.map((item) => (
            <button
              key={item}
              onClick={() => { onTabChange(item); setMobileOpen(false); }}
              className={`px-3 py-2 text-sm rounded-lg text-left transition-colors ${
                activeTab === item ? 'text-bubble-accent bg-bubble-accent/10' : 'text-bubble-muted hover:text-bubble-text hover:bg-white/5'
              }`}
            >
              {item}
            </button>
          ))}
        </motion.div>
      )}
    </header>
  );
}

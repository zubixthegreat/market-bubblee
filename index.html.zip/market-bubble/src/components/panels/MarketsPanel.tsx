'use client';
import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, RefreshCw } from 'lucide-react';
import { MOCK_MARKETS, MOCK_NARRATIVES, SENTIMENT_DATA } from '@/data/mockData';
import Sparkline from '@/components/ui/Sparkline';
import { MarketAsset } from '@/types';
import { drift } from '@/lib/utils';

function useLiveMarkets() {
  const [markets, setMarkets] = useState<MarketAsset[]>(() =>
    MOCK_MARKETS.map((m) => ({ ...m }))
  );
  const [lastUpdate, setLastUpdate] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => {
      setMarkets((prev) =>
        prev.map((asset) => {
          const newPrice = drift(asset.price, asset.price * 0.003);
          const basePct = MOCK_MARKETS.find((m) => m.symbol === asset.symbol)!.changePct24h;
          return {
            ...asset,
            price: newPrice,
            sparkline: [...asset.sparkline.slice(1), newPrice],
          };
        })
      );
      setLastUpdate(new Date());
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  return { markets, lastUpdate };
}

function formatPrice(price: number, symbol: string): string {
  if (symbol === 'XRP') return `$${price.toFixed(3)}`;
  if (price >= 1000) return `$${Math.round(price).toLocaleString()}`;
  return `$${price.toFixed(2)}`;
}

export default function MarketsPanel() {
  const { markets, lastUpdate } = useLiveMarkets();
  const prevPrices = useRef<Record<string, number>>({});
  const [flashMap, setFlashMap] = useState<Record<string, 'up' | 'down' | null>>({});

  useEffect(() => {
    const newFlash: Record<string, 'up' | 'down' | null> = {};
    markets.forEach((m) => {
      const prev = prevPrices.current[m.symbol];
      if (prev !== undefined) {
        newFlash[m.symbol] = m.price > prev ? 'up' : m.price < prev ? 'down' : null;
      }
      prevPrices.current[m.symbol] = m.price;
    });
    setFlashMap(newFlash);
    const t = setTimeout(() => setFlashMap({}), 600);
    return () => clearTimeout(t);
  }, [markets]);

  return (
    <div className="flex flex-col gap-3 p-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="font-display font-semibold text-sm text-bubble-text">Live Markets</h2>
        <div className="flex items-center gap-1.5">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
          >
            <RefreshCw size={10} className="text-bubble-dim" />
          </motion.div>
          <span className="text-[10px] text-bubble-muted font-mono">
            {lastUpdate.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false })}
          </span>
        </div>
      </div>

      {/* Market cards */}
      <div className="space-y-2">
        {markets.map((asset, i) => {
          const flash = flashMap[asset.symbol];
          return (
            <motion.div
              key={asset.symbol}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="glass-panel glass-panel-hover rounded-xl p-3 cursor-pointer transition-all duration-200"
            >
              <div className="flex items-center gap-2.5">
                {/* Icon */}
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-bubble-dim to-bubble-border flex items-center justify-center flex-shrink-0">
                  <span className="text-xs font-black text-bubble-text">{asset.symbol[0]}</span>
                </div>

                {/* Name + sentiment */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-bubble-text">{asset.symbol}</span>
                    <span
                      className={`text-[9px] px-1 py-px rounded font-mono font-bold ${
                        asset.sentiment === 'bullish'
                          ? 'bg-bubble-green/10 text-bubble-green'
                          : asset.sentiment === 'bearish'
                          ? 'bg-bubble-red/10 text-bubble-red'
                          : 'bg-bubble-amber/10 text-bubble-amber'
                      }`}
                    >
                      {asset.sentiment.toUpperCase()}
                    </span>
                  </div>
                  <div className="text-[10px] text-bubble-dim truncate">{asset.name}</div>
                </div>

                {/* Price + change */}
                <div className="text-right mr-1">
                  <motion.div
                    key={`${asset.symbol}-${Math.round(asset.price)}`}
                    animate={
                      flash === 'up'
                        ? { color: ['#E8EDF5', '#00E676', '#E8EDF5'] }
                        : flash === 'down'
                        ? { color: ['#E8EDF5', '#FF4444', '#E8EDF5'] }
                        : {}
                    }
                    transition={{ duration: 0.5 }}
                    className="text-xs font-mono font-semibold text-bubble-text"
                  >
                    {formatPrice(asset.price, asset.symbol)}
                  </motion.div>
                  <div
                    className={`text-[10px] font-mono flex items-center gap-0.5 justify-end ${
                      asset.changePct24h >= 0 ? 'text-bubble-green' : 'text-bubble-red'
                    }`}
                  >
                    {asset.changePct24h >= 0 ? (
                      <TrendingUp size={9} />
                    ) : (
                      <TrendingDown size={9} />
                    )}
                    {asset.changePct24h >= 0 ? '+' : ''}
                    {asset.changePct24h.toFixed(2)}%
                  </div>
                </div>

                {/* Sparkline */}
                <Sparkline
                  data={asset.sparkline}
                  positive={asset.changePct24h >= 0}
                  width={56}
                  height={26}
                />
              </div>

              {/* Volume + Market cap row */}
              <div className="flex justify-between mt-2 pt-2 border-t border-bubble-border/50">
                <div className="text-[10px] text-bubble-dim">
                  Vol: <span className="text-bubble-muted font-mono">{asset.volume}</span>
                </div>
                <div className="text-[10px] text-bubble-dim">
                  MCap: <span className="text-bubble-muted font-mono">{asset.marketCap}</span>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Sentiment gauge */}
      <div className="glass-panel rounded-xl p-4">
        <h3 className="text-[11px] font-semibold text-bubble-muted uppercase tracking-wider mb-3">
          Market Sentiment
        </h3>
        <div className="flex h-2 rounded-full overflow-hidden gap-px mb-3">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${SENTIMENT_DATA.bullish}%` }}
            transition={{ duration: 1, ease: 'easeOut' }}
            className="bg-bubble-green rounded-l-full"
          />
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${SENTIMENT_DATA.neutral}%` }}
            transition={{ duration: 1, delay: 0.15, ease: 'easeOut' }}
            className="bg-bubble-amber"
          />
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${SENTIMENT_DATA.bearish}%` }}
            transition={{ duration: 1, delay: 0.3, ease: 'easeOut' }}
            className="bg-bubble-red rounded-r-full"
          />
        </div>
        <div className="grid grid-cols-3 text-center">
          {[
            { label: 'Bullish', value: SENTIMENT_DATA.bullish, color: 'text-bubble-green' },
            { label: 'Neutral', value: SENTIMENT_DATA.neutral, color: 'text-bubble-amber' },
            { label: 'Bearish', value: SENTIMENT_DATA.bearish, color: 'text-bubble-red'  },
          ].map(({ label, value, color }) => (
            <div key={label}>
              <div className={`text-sm font-bold font-mono ${color}`}>{value}%</div>
              <div className="text-[10px] text-bubble-dim mt-0.5">{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Trending Narratives */}
      <div className="glass-panel rounded-xl p-4">
        <h3 className="text-[11px] font-semibold text-bubble-muted uppercase tracking-wider mb-3">
          Trending Narratives
        </h3>
        <div className="space-y-2.5">
          {MOCK_NARRATIVES.map((n, i) => (
            <div key={n.id} className="flex items-center gap-2">
              <span className="text-[10px] text-bubble-dim font-mono w-4 text-right flex-shrink-0">
                {i + 1}
              </span>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-0.5">
                  <span className="text-xs text-bubble-text truncate">{n.topic}</span>
                  <span
                    className={`text-[10px] font-mono ml-2 flex-shrink-0 ${
                      n.change >= 0 ? 'text-bubble-green' : 'text-bubble-red'
                    }`}
                  >
                    {n.change >= 0 ? `+${n.change}%` : `${n.change}%`}
                  </span>
                </div>
                <div className="h-1 bg-bubble-dim rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${(n.mentions / 847) * 100}%` }}
                    transition={{ duration: 0.8, delay: i * 0.04, ease: 'easeOut' }}
                    className={`h-full rounded-full ${
                      n.sentiment === 'bullish'
                        ? 'bg-bubble-green'
                        : n.sentiment === 'bearish'
                        ? 'bg-bubble-red'
                        : 'bg-bubble-amber'
                    }`}
                  />
                </div>
              </div>
              <span className="text-[10px] font-mono text-bubble-dim w-8 text-right flex-shrink-0">
                {n.mentions}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

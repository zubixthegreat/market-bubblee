'use client';
import { motion } from 'framer-motion';

interface LiveIndicatorProps {
  viewers?: number;
  className?: string;
}

export default function LiveIndicator({ viewers, className = '' }: LiveIndicatorProps) {
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <div className="relative flex items-center justify-center">
        <motion.div
          className="absolute w-4 h-4 rounded-full bg-green-500 opacity-30"
          animate={{ scale: [1, 1.8, 1], opacity: [0.3, 0, 0.3] }}
          transition={{ duration: 2, repeat: Infinity }}
        />
        <div className="w-2.5 h-2.5 rounded-full bg-bubble-green shadow-glow-green" />
      </div>
      <span className="text-xs font-mono font-semibold text-bubble-green tracking-wider">LIVE</span>
      {viewers && (
        <span className="text-xs font-mono text-bubble-muted">
          {viewers.toLocaleString()} viewers
        </span>
      )}
    </div>
  );
}

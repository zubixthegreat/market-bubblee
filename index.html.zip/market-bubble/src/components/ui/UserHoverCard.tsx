'use client';
import { motion } from 'framer-motion';
import { Platform } from '@/types';
import PlatformBadge from './PlatformBadge';

interface UserHoverCardProps {
  username: string;
  avatar: string;
  platform: Platform;
  followers?: number;
  bio?: string;
  verified?: boolean;
}

export default function UserHoverCard({ username, avatar, platform, followers, bio, verified }: UserHoverCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95, y: 4 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95, y: 4 }}
      className="glass-panel rounded-xl p-3 w-56 shadow-glass z-50 pointer-events-none"
    >
      <div className="flex items-center gap-2.5 mb-2">
        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-bubble-accent/30 to-bubble-accent2/30 flex items-center justify-center text-sm font-bold text-bubble-accent border border-bubble-accent/20">
          {avatar}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            <span className="text-sm font-semibold text-bubble-text truncate">{username}</span>
            {verified && <span className="text-xs text-bubble-accent">✓</span>}
          </div>
          <PlatformBadge platform={platform} size="sm" />
        </div>
      </div>
      {bio && <p className="text-xs text-bubble-muted leading-relaxed mb-2">{bio}</p>}
      {followers && (
        <div className="text-xs text-bubble-muted font-mono">
          <span className="text-bubble-text font-semibold">{followers.toLocaleString()}</span> followers
        </div>
      )}
    </motion.div>
  );
}

'use client';
import { motion, AnimatePresence } from 'framer-motion';
import { useEffect, useState } from 'react';

const STEPS = [
  { label: 'Connecting to live feeds', detail: 'Twitch · Kick · X' },
  { label: 'Aggregating chat streams', detail: 'Merging platform audiences' },
  { label: 'Loading market data', detail: 'BTC · ETH · SOL · BNB · XRP' },
  { label: 'Initialising Bubble AI', detail: 'Stream intelligence engine' },
  { label: 'Dashboard ready', detail: 'Market Bubble' },
];

interface LoadingScreenProps {
  onComplete: () => void;
}

export default function LoadingScreen({ onComplete }: LoadingScreenProps) {
  const [step, setStep] = useState(0);
  const [progress, setProgress] = useState(0);
  const [done, setDone] = useState(false);

  useEffect(() => {
    const stepMs = 420;
    const interval = setInterval(() => {
      setStep((s) => {
        const next = s + 1;
        setProgress(Math.round((next / STEPS.length) * 100));
        if (next >= STEPS.length) {
          clearInterval(interval);
          setTimeout(() => {
            setDone(true);
            setTimeout(onComplete, 400);
          }, 500);
        }
        return Math.min(next, STEPS.length - 1);
      });
    }, stepMs);
    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <AnimatePresence>
      {!done && (
        <motion.div
          key="loading"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 1.02 }}
          transition={{ duration: 0.4 }}
          className="fixed inset-0 z-[100] bg-bubble-bg flex flex-col items-center justify-center"
        >
          {/* Background grid */}
          <div
            className="absolute inset-0 opacity-[0.03]"
            style={{
              backgroundImage:
                'linear-gradient(rgba(0,212,255,1) 1px,transparent 1px),linear-gradient(90deg,rgba(0,212,255,1) 1px,transparent 1px)',
              backgroundSize: '48px 48px',
            }}
          />

          {/* Glow */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full bg-bubble-accent/5 blur-3xl pointer-events-none" />

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="relative flex flex-col items-center gap-8 w-72"
          >
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-bubble-accent to-bubble-accent2 flex items-center justify-center shadow-accent">
                <span className="text-sm font-black text-white">MB</span>
              </div>
              <div>
                <div className="font-display font-bold text-lg text-bubble-text tracking-tight leading-none">
                  Market<span className="text-bubble-accent"> Bubble</span>
                </div>
                <div className="text-[11px] text-bubble-muted font-mono mt-0.5 tracking-wider">
                  UNIFIED LIVE DASHBOARD
                </div>
              </div>
            </div>

            {/* Steps */}
            <div className="w-full space-y-2.5">
              {STEPS.map((s, i) => {
                const state = i < step ? 'done' : i === step ? 'active' : 'pending';
                return (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: state === 'pending' ? 0.3 : 1, x: 0 }}
                    transition={{ delay: i * 0.08 }}
                    className="flex items-center gap-3"
                  >
                    <div className="w-4 h-4 rounded-full flex items-center justify-center flex-shrink-0">
                      {state === 'done' && (
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className="w-4 h-4 rounded-full bg-bubble-green flex items-center justify-center"
                        >
                          <svg width="8" height="8" fill="none" stroke="black" strokeWidth="2">
                            <polyline points="1,4 3,6 7,2" />
                          </svg>
                        </motion.div>
                      )}
                      {state === 'active' && (
                        <motion.div
                          animate={{ opacity: [1, 0.3, 1] }}
                          transition={{ duration: 0.8, repeat: Infinity }}
                          className="w-3 h-3 rounded-full bg-bubble-accent"
                        />
                      )}
                      {state === 'pending' && (
                        <div className="w-3 h-3 rounded-full border border-bubble-dim" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div
                        className={`text-xs font-medium ${
                          state === 'done'
                            ? 'text-bubble-muted'
                            : state === 'active'
                            ? 'text-bubble-text'
                            : 'text-bubble-dim'
                        }`}
                      >
                        {s.label}
                      </div>
                      {state === 'active' && (
                        <motion.div
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="text-[10px] text-bubble-muted font-mono mt-0.5"
                        >
                          {s.detail}
                        </motion.div>
                      )}
                    </div>
                  </motion.div>
                );
              })}
            </div>

            {/* Progress bar */}
            <div className="w-full">
              <div className="flex justify-between text-[10px] font-mono text-bubble-dim mb-1.5">
                <span>Initialising</span>
                <motion.span
                  key={progress}
                  initial={{ opacity: 0.5 }}
                  animate={{ opacity: 1 }}
                >
                  {progress}%
                </motion.span>
              </div>
              <div className="h-px bg-bubble-dim rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-bubble-accent to-bubble-accent2 rounded-full"
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.3, ease: 'easeOut' }}
                />
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

'use client';
import { Platform } from '@/types';

const PLATFORM_CONFIG: Record<Platform, { label: string; color: string; bg: string; icon: string }> = {
  twitch: { label: 'Twitch', color: '#9146FF', bg: 'rgba(145,70,255,0.15)', icon: '📡' },
  x: { label: 'X', color: '#E8EDF5', bg: 'rgba(232,237,245,0.08)', icon: '𝕏' },
  kick: { label: 'Kick', color: '#53FC18', bg: 'rgba(83,252,24,0.1)', icon: '⚡' },
  bubble: { label: 'Bubble', color: '#00D4FF', bg: 'rgba(0,212,255,0.1)', icon: '🫧' },
};

interface PlatformBadgeProps {
  platform: Platform;
  size?: 'sm' | 'md';
}

export default function PlatformBadge({ platform, size = 'sm' }: PlatformBadgeProps) {
  const config = PLATFORM_CONFIG[platform];
  return (
    <span
      className={`inline-flex items-center gap-1 rounded font-mono font-semibold border ${size === 'sm' ? 'text-[10px] px-1.5 py-0.5' : 'text-xs px-2 py-1'}`}
      style={{ color: config.color, background: config.bg, borderColor: config.color + '44' }}
    >
      <span>{config.icon}</span>
      <span>{config.label}</span>
    </span>
  );
}

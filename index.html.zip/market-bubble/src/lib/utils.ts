export function formatPrice(price: number, symbol?: string): string {
  if (symbol === 'XRP') return `$${price.toFixed(3)}`;
  if (price >= 1000) return `$${Math.round(price).toLocaleString('en-US')}`;
  if (price >= 1) return `$${price.toFixed(2)}`;
  return `$${price.toFixed(4)}`;
}

export function formatCompact(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return n.toString();
}

export function formatTime(date: Date): string {
  return date.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });
}

export function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}

export function randomBetween(min: number, max: number): number {
  return Math.random() * (max - min) + min;
}

/** Drift a number by ±maxDelta, staying positive */
export function drift(current: number, maxDelta: number): number {
  const delta = (Math.random() - 0.45) * maxDelta;
  return Math.max(0, current + delta);
}
